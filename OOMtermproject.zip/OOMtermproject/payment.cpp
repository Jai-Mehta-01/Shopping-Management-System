#include<bits/stdc++.h>
#include<unistd.h>
#include"payment.h"
#include"bill.h"
#include"clothes.h"
#include"customer.h"
#include"watches.h"
#include"books.h"
#include<time.h>
using namespace std;
namespace sample
{
    long int ms=pow(10,6);
    void payment::verify_user()
    {
        cout<<"Verification of account............\n";
        cout<<"Please wait for a while\n\n";
        usleep(5*ms);
        cout<<"--------------~ Verified ~----------------\n\n";
    }
    void payment::get_payment_mode()
    {
        cout<<"Enter you desired mode of payment\n";
        cout<<"1. Debit-Card\n";
        cout<<"2. Credit-Card\n";
        cout<<"3. UPI\n";
        cout<<"4. PAYTM\n";
        int ch;
        cin>>ch;
           system("clear");
        
        if(ch==1)
        {
            payment_mode="Debit-Card";
        }
        else if(ch==2)
        {
            payment_mode="Credit-Card";
        }
        else if(ch==3)
        {
            payment_mode="UPI";
        }
        else if(ch==4)
        {
            payment_mode="PAYTM";
        }
        else
        {
            cout<<"INVALID INPUT\n";
            cout<<"Choose again\n";
            get_payment_mode();
        }
    }
    void payment::display_payment_details()
    {
        srand(time(0));
        cout<<"\n\nProcessing payment\n\n";
        cout<<"please wait...\n\n";
        usleep(5*ms);
        system("clear");
        cout<<"Payment successfull\n\n";
        ifstream admin_total("total_income.txt");
        double tot;
        while(admin_total>>tot)
        {
            int t=0;
        }
        admin_total.close();
        string prod_typ,prod,ids;
        int quantity;
        float total_price;
        fstream cart("current_user.txt");
        float cart_total=0;
        string us,mob,em;
        int f=0;
        while(!cart.eof())
        {
            if(f==0)
            {
                cart>>us>>mob>>em;
                f=1;
            }
            else
            {   cart>>ids>>prod_typ>>prod>>quantity>>total_price;
                cart_total+=total_price;
            }
        }
        tot+=cart_total;
        ofstream admin_to("total_income.txt");
        admin_to<<tot;
        admin_to.close();
        cart.close();
        cout<<"You made payment through: "<<payment_mode<<'\n';
        cout<<"Your Payment id generated is: "<<rand()%((int)(pow(10,6)))<<'\n'<<'\n';
        cout<<"A code has been sent to your registered mobile number\n";
        cout<<"Kindly make sure that it matches with the id generated\n";
        cout<<"In case of mismatch kindly contact Support at - 8787878787\n\n";
        cout<<"Please drop your valuable feedback\n\n";
        fstream open("feedback.txt",ios::app);
        string feed;
        getline(cin>>ws,feed);
        open<<feed<<endl;
        open.close();
        cout<<'\n';
        system("clear");
        cout<<"Thank you for your valueable feedback\n";
        cout<<"\nThank you for shopping with us and have a great day ahead :)\n";
        cout<<"Logging out....\n\n";
        usleep(3*ms);
        system("clear");
        exit(1);
    }
} 
