#ifndef __PRODUCTS
#define __PRODUCTS

#include<bits/stdc++.h>
#include<fstream>
#include"customer.h"
#include"user.h"
#include"bill.h"
using namespace std;

namespace sample
{

    class products
    {
        protected:
            int quantity;
            float price;
            int id;
            static int counter;
            customer obj;
        public:

            virtual void show_menu()=0;
            void input_quantity();
           
    	    int return_quan();
            void set_price(float);
            float return_price();
            float total_price();
            int get_id();
            virtual void add_to_cart()=0;


    };
}
#endif // __PRODUCTS
