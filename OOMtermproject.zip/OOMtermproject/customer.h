#ifndef __CUSTOMER_HEADER
#define __CUSTOMER_HEADER

#include<bits/stdc++.h>
#include"user.h"
#include"bill.h"
using namespace std;
namespace sample
{
    class customer:public user
    {
        private:
            bill invoice;
        public:
            int login();
            int signup();
            void show_invoice();
            void show_the_cart_total();
    };
}
#endif // __CUSTOMER_HEADER
