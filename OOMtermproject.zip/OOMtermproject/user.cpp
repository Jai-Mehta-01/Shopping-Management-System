#include<bits/stdc++.h>
#include<fstream>
#include"user.h"
using namespace std;
namespace sample
{
	void user::input_username()
	{
		cin>>username;
	}
	void user::input_password()
	{
		cin>>password;
	}
	string user::access_username()
	{
		return username;
	}
	string user::access_password()
	{
		return password;
	}
	void user::set_username(string us)
	{
		username=us;
	}

}

