#include<bits/stdc++.h>
#include<fstream>
#include"user.h"
#include"customer.h"
#include"admin.h"
#include"product.h"
#include"welcome.h"
using namespace std;


namespace sample
{



    void welcome::show_home_page()
    {
        cout<<'\n';
        cout<<"＊＊＊＊＊＊＊＊＊＊＊＊＊＊  ＷＥＬＣＯＭＥ ＴＯ ＴＨＥ ＳＨＯＰＰＩＮＧ ＣＥＮＴＥＲ  ＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊\n\n";
        cout<<"1. LOGIN\n";
        cout<<"2. SIGN UP\n";
        cout<<"3. ADMIN LOGIN\n";
        cout<<"4. EXIT\n";
        cout<<"Enter your choice as the number indicated before the choices:\n";
        int ch,check;
        cin>>ch;
        system("clear");

        if(ch==1)
        {
            system("clear");
            customer old_customer;

            cout<<"ENTER USERNAME : ";
            old_customer.input_username();
            cout<<"ENTER PASSWORD : ";
            old_customer.input_password();

            if(!old_customer.login())
            {
                show_home_page();
            }
        }

        else if(ch==2)
        {

            system("clear");
            customer new_user;

            cout<<"ENTER USERNAME : ";
            new_user.input_username();
            cout<<"ENTER PASSWORD : ";
            new_user.input_password();
            system("clear");
            if(!new_user.signup())
            {
                show_home_page();
            }

        }

        else if(ch==3)
        {
            system("clear");
            admin an_admin;
            
            cout<<"ENTER USERNAME : ";
            an_admin.input_username();
            cout<<"ENTER PASSWORD : ";
            an_admin.input_password();
            system("clear");
            if(!an_admin.login())
            {
                show_home_page();
            }

            else
            {
                an_admin.privileges();
            }
        }


        else if(ch==4)
        {
            cout<<"You have been exited out of the shopping menu\nHave a nice day :)\nVisit again...\n";
            exit(1);
        }


        else
        {
            cout<<'\a';
            cout<<"Invalid input\n";
            cout<<"Please choose only from the four options as 1,2,3 or 4 ...\ntry again\n";
            show_home_page();
        }
    }
}
