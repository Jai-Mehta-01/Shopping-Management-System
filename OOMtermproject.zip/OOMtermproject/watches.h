#ifndef __WATCHES
#define __WATCHES

#include<bits/stdc++.h>
#include"product.h"

namespace sample
{
    class watches:public products
    {
        private:
            string type_of_watch;
            string material_of_watch;

        public:
            void show_menu();
            void add_to_cart();
    };
}

#endif // __WATCHES
