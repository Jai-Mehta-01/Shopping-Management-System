#ifndef __payment
#define __payment
#include<bits/stdc++.h>
using namespace std;
namespace sample
{
    class payment
    {
        private:
            string payment_mode;
        public:
            void verify_user();
            void display_payment_details();
            void get_payment_mode();

    };
}
#endif