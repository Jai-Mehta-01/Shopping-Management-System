#include<bits/stdc++.h>
#include"product.h"
#include<fstream>
#include<time.h>
using namespace std;
namespace sample
{
  
   int products::counter=0;
   int products::get_id()
    {
      counter+=return_quan();
      id =counter;
      return id;
        
    }
    
    float products::total_price()
    {
        float total=return_quan()*return_price();
        cout<<"Your total would be => ";
        auto str=std::to_string(total);
        cout<<str<<'\n';
        return total;
    }
    void products::input_quantity()
    {
        cin>>quantity;
    }
    void products::set_price(float pric)
    {   
        price=pric;
    }
    int products::return_quan()
    {
    	return quantity;
    }
    float products::return_price()
    {
        return price;
    }

}



