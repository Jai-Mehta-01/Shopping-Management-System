#ifndef __MAIN_USER
#define __MAIN_USER

#include<bits/stdc++.h>
#include<fstream>
using namespace std;
namespace sample
{
    class user
    {
        private:
            string username;
            string password;
        public:
            virtual int login()=0;
            string access_username();
            string access_password();
            void input_username();
            void input_password();
            void set_username(string);
           
    };
}
#endif // __MAIN_USER
