#include<bits/stdc++.h>
#include<fstream>
#include"user.h"
#include"customer.h"
#include"bill.h"
using namespace std;
namespace sample
{
    int customer::login()
    {
        int cnt=0;
        string us,pass;
        fstream input("database.txt");
        while(input>>us>>pass)
        {
            if(us==access_username() && pass==access_password())
            {
                system("clear");
                cout<<"Login successful.\nHello "<<us<<'\n';
                cnt=1;
                input.close();
    	        string names,num,email;
                
                fstream open("contact.txt");
                fstream current("current_user.txt");

                while(open>>names>>num>>email)
                {
                    if(names==access_username())
                    {
                        cout<<"Phone number : "<<num<<'\n';
                        cout<<"Email : "<<email<<'\n';
                        current<<names<<" "<<num<<" "<<email<<'\n';
                        break;
                    }
                }
    	        open.close();
                current.close();
            }
            else if(us==access_username())
            {
                cnt=-1;
            }
            else
            {
                cnt=0;
            }
        }
        if(cnt==-1)
        {
            system("clear");
            cout<<'\a';
            cout<<"Sorry :(\n";
            cout<<"Password is incorrect\nLogin Failed.\n";
            input.close();
            return 0;
        }
        else if(cnt==0)
        {
            cout<<'\a';
            cout<<"User could not be found.\nTry again with correct credentials or register as a new user\n";
            return 0;
        }
        return 1;
    }
    int customer::signup()
    {
        int cntt=0;
        string us,pass;
        fstream input("database.txt",ios::in);
        while(input>>us>>pass)
        {
            if(us==access_username())
            {
                cout<<'\a';
                cout<<"Username already taken\n";
                cout<<"Try again with a different username...\n";
                return 0;
            }
        }
        input.close();
        fstream output("database.txt",ios::app);
        output<<'\n'<<access_username()<<' '<<access_password();
        output.close();
        system("clear");
        cout<<"ENTER YOUR PHONE NUMBER : ";
        string number;
        cin>>number;
        cout<<"ENTER EMAIL ADDRESS : ";
        string email;
        cin>>email;
        string names=access_username();
        
        
        fstream add("contact.txt",ios::app);
        fstream current("current_user.txt");
        add<<names<<" "<<number<<" "<<email<<'\n';
        current<<names<<" "<<number<<" "<<email<<'\n';
        current.close();
        add.close();
        system("clear");
        cout<<"Successfully registered :)\nContinue shopping\n";
        return 1;
    }
    void customer::show_invoice()
    {
        invoice.show_bill();
    }
    void customer::show_the_cart_total()
    {
        invoice.show_cart_total();
    }

}
