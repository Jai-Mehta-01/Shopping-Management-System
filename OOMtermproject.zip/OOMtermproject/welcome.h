#ifndef __WELCOME_HEADER
#define __WELCOME_HEADER

#include<bits/stdc++.h>
#include<fstream>
using namespace std;

namespace sample
{

    class welcome
    {
        public:
            void show_home_page();
    };
}
#endif // __WELCOME_HEADER
