#ifndef __CATALOGUE
#define __CATALOGUE
#include<bits/stdc++.h>
#include<fstream>
using namespace std;
namespace sample
{
    class catalogue
    {
        public:
            void show_catalogue();
    };
}
#endif // __CATALOGUE
