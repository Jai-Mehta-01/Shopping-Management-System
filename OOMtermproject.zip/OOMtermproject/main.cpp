#include<bits/stdc++.h>
#include<fstream>
#include"welcome.h"
#include"catalogue.h"
#include"product.h"
#include<time.h>
using namespace std;
using namespace sample;

 

int main()
{
    system("clear");
    ofstream ofs;
    ofs.open("current_user.txt", ios::out | ios::trunc);
    ofs.close();
    welcome obj1;
    catalogue obj2;
    obj1.show_home_page();
    obj2.show_catalogue();

}
