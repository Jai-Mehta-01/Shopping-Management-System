#include<bits/stdc++.h>
#include"product.h"
#include"watches.h"
#include"catalogue.h"
#include"bill.h"
#include"customer.h"
using namespace std;

namespace sample
{
    catalogue show3;
    void watches::add_to_cart()
    {
    
        cout<<"Added to cart successfully\n";
        ofstream output("current_user.txt",ios::app);
        output<<endl<<get_id()<<" "<<"watch "<<type_of_watch<<"("<<material_of_watch<<") "<<return_quan()<<" "<<total_price();
        output.close();
    }
    void watches::show_menu()
    {
        do
        {
            cout<<"1. Clocks\n";
            cout<<"2. Wrist Watches for men\n";
            cout<<"3. Wrist Watches for Women\n";
            cout<<"4. Watches for kids\n";
            cout<<"ENTER YOUR CHOICE : ";
            string op1;
            cin>>op1;
            system("clear");
            int z=stoi(op1);
            if(z<1 || z>4)
            {
                cout<<'\a';
                cout<<"Wrong type selection\nRetrieving to the menu\nTry again\n";
                continue;
            }
            cout<<"What material would you like to wear\n";
            cout<<"1. Steel\n";
            cout<<"2. Gold\n";
            cout<<"3. Silver\n";
            string op2;
            cin>>op2;
            system("clear");
            z=stoi(op2);
            if(z<1 || z>3)
            {
                cout<<'\a';
                cout<<"Wrong type selection\nRetrieving to the menu\nTry again\n";
                continue;
            }
      
            int data_mismatch=1;
            fstream watches("watches.txt");
            string ch1,ch2,typ,mat;
            float pric;
            while(watches>>ch1>>ch2>>typ>>mat>>pric)
            {
                if(ch1==op1 && ch2==op2)
                {
                    type_of_watch=typ;
                    material_of_watch=mat;
                    price=pric;
                    data_mismatch=0;
                    break;
                }
            }
            if(data_mismatch)
            {
                cout<<'\a';
                cout<<"Wrong type selection\nRetrieving to the menu\nTry again\n";
                continue;
            }
            cout<<'\n';
            cout<<type_of_watch<<" "<<material_of_watch<<" "<<"Rs."<<price<<'\n';
            cout<<'\n';
            cout<<"Would you like to buy it\nEnter 1 for Yes  or 2 to go back : ";
            int d;
            cin>>d;
            system("clear");
            fstream file("current_user.txt");
            string us;
            file>>us;
            obj.set_username(us);
            if(d==1)
            {
                cout<<"Tell the quantity : ";
                input_quantity();
                cout<<"Press c to add to cart\n";
                cout<<"Press a to choose again\n";
                cout<<"Press q to show bill and quit\n";
                cout<<"Press t to get cart total\n";
                char u;
                cin>>u;
                system("clear");
                if(u=='c')
                {
        		    
                    add_to_cart();
                    cout<<"To see your bill press b and to continue shopping Press any other key\n";
                  
                    char x;
                    cin>>x;
                    system("clear");
                    if(x=='B'||x=='b')
                    {
                        obj.show_invoice();
                    }
                    else
                    {
                       show3.show_catalogue();
                    }
                }
                if(u=='q')
                {
                    obj.show_the_cart_total();
                    exit(1);
                }
                if(u=='a')
                {
                    show_menu();
                }
                if(u=='t')
                {
                    cout<<"Your bill till now is : ";
                    obj.show_the_cart_total();
                    cout<<'\n';
                }

            }
            break;
        }while(1);
    }
}
